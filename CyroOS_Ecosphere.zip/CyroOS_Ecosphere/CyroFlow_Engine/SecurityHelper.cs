using System.Security.Cryptography;
using System.Text;

namespace CyroFlow_Engine; // Dikkat: Namespace bu klasöre uygun olmalı

public static class SecurityHelper
{
    public static string Encrypt(string text, string key)
    {
        if (string.IsNullOrEmpty(text)) return string.Empty;
        using Aes aes = Aes.Create();
        aes.Key = SHA256.HashData(Encoding.UTF8.GetBytes(key));
        aes.IV = new byte[16]; 
        using var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
        byte[] buffer = Encoding.UTF8.GetBytes(text);
        return Convert.ToBase64String(encryptor.TransformFinalBlock(buffer, 0, buffer.Length));
    }

    public static string Decrypt(string cipherText, string key)
    {
        if (string.IsNullOrEmpty(cipherText)) return string.Empty;
        try {
            using Aes aes = Aes.Create();
            aes.Key = SHA256.HashData(Encoding.UTF8.GetBytes(key));
            aes.IV = new byte[16];
            using var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
            byte[] buffer = Convert.FromBase64String(cipherText);
            return Encoding.UTF8.GetString(decryptor.TransformFinalBlock(buffer, 0, buffer.Length));
        } catch { return "!!! DECRYPT_ERR !!!"; }
    }
}