using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options => {
    options.AddDefaultPolicy(policy => policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
});

var app = builder.Build();

app.UseCors();
app.UseDefaultFiles();
app.UseStaticFiles();

string flowLogDb = "Data/flow_logs.json";
if (!Directory.Exists("Data")) Directory.CreateDirectory("Data");

// --- FLOW API ---

// 1. Logları CyroNode'a servis eden endpoint
app.MapGet("/api/flow/status", async () => {
    if (!File.Exists(flowLogDb)) return Results.Ok(new { status = "ACTIVE", history = "[]" });
    
    var rawJson = await File.ReadAllTextAsync(flowLogDb);
    return Results.Ok(new { status = "ACTIVE", history = rawJson });
});

// 2. CyroAuth'tan gelen sinyalleri yakalayan endpoint
app.MapPost("/api/flow/trigger", async (FlowEvent ev) => {
    var rawJson = File.Exists(flowLogDb) ? await File.ReadAllTextAsync(flowLogDb) : "[]";
    var logs = JsonSerializer.Deserialize<List<FlowEvent>>(rawJson) ?? new List<FlowEvent>();
    
    ev.Timestamp = DateTime.Now;
    logs.Add(ev);
    
    // JSON'u dosyaya güzel formatta yaz (okunabilirlik için)
    await File.WriteAllTextAsync(flowLogDb, JsonSerializer.Serialize(logs, new JsonSerializerOptions { WriteIndented = true }));
    
    return Results.Ok("Signal_Captured");
});

app.Run("http://localhost:8080");

public class FlowEvent {
    public string ActionName { get; set; } = "";
    public string SourceNode { get; set; } = "";
    public DateTime Timestamp { get; set; }
}