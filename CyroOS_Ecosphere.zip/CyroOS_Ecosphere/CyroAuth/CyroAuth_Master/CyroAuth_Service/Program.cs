using System.Text.Json;
using System.Text;
using CyroAuth_Service; // SecurityHelper'a erişim için

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();

// --- VERİ YOLLARI VE KLASÖR KONTROLÜ ---
string userDb = "Data/identities.json";
string vaultDb = "Data/vault.json";
if (!Directory.Exists("Data")) Directory.CreateDirectory("Data");

// --- HABERCİ (TRIGGER) FONKSİYONU ---
// CyroFlow'a (8080) olay sinyali gönderir
async Task SendFlowSignal(string action) {
    try {
        using var client = new HttpClient();
        client.Timeout = TimeSpan.FromSeconds(1); // Sistemi yavaşlatmaması için kısa timeout
        var payload = new { ActionName = action, SourceNode = "CyroAuth-Master" };
        var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
        await client.PostAsync("http://localhost:8080/api/flow/trigger", content);
    } catch {
        // Flow kapalıysa sistemin çökmemesi için sessizce devam et
    }
}

// --- 1. KİMLİK KAYIT ---
app.MapPost("/api/auth/register", async (User newUser) => {
    var rawJson = File.Exists(userDb) ? await File.ReadAllTextAsync(userDb) : "[]";
    var users = JsonSerializer.Deserialize<List<User>>(rawJson) ?? new List<User>();
    
    if (users.Any(u => u.Username.ToLower() == newUser.Username.ToLower())) 
        return Results.BadRequest("Sisteme Giriş Engellendi: Kimlik zaten mevcut.");
    
    users.Add(newUser);
    await File.WriteAllTextAsync(userDb, JsonSerializer.Serialize(users));
    
    await SendFlowSignal($"NEW_IDENTITY_SYNC: {newUser.Username}");
    return Results.Ok();
});

// --- 2. MASTER LOGIN ---
app.MapPost("/api/auth/login", async (User loginData) => {
    if (!File.Exists(userDb)) return Results.Unauthorized();
    
    var users = JsonSerializer.Deserialize<List<User>>(await File.ReadAllTextAsync(userDb)) ?? new List<User>();
    var user = users.FirstOrDefault(u => u.Username.ToLower() == loginData.Username.ToLower() && u.Password == loginData.Password);

    if (user == null) {
        await SendFlowSignal($"UNAUTHORIZED_ACCESS_ATTEMPT: {loginData.Username}");
        return Results.Unauthorized();
    }
    
    await SendFlowSignal($"OPERATOR_AUTHORIZED: {user.Username}");
    return Results.Ok(user);
});

// --- 3. KASA ERİŞİMİ (VAULT SYNC) ---
app.MapPost("/api/vault/sync", async (VaultRequest req) => {
    var users = JsonSerializer.Deserialize<List<User>>(await File.ReadAllTextAsync(userDb)) ?? new List<User>();
    var user = users.FirstOrDefault(u => u.Username == req.Owner && u.Password == req.VaultKey);
    
    if (user == null) {
        await SendFlowSignal("VAULT_ACCESS_DENIED: Invalid Key");
        return Results.Problem("Hatalı Kasa Anahtarı.");
    }

    if (!File.Exists(vaultDb)) return Results.Ok(new List<VaultAsset>());
    
    var all = JsonSerializer.Deserialize<List<VaultAsset>>(await File.ReadAllTextAsync(vaultDb)) ?? new List<VaultAsset>();
    var userAssets = all.Where(a => a.Owner == req.Owner).ToList();
    
    // Verileri SecurityHelper ile deşifre et
    userAssets.ForEach(a => a.Value = SecurityHelper.Decrypt(a.Value, req.VaultKey));
    
    await SendFlowSignal($"VAULT_DECRYPTED: {req.Owner}");
    return Results.Ok(userAssets);
});

// --- 4. VARLIK EKLEME (VAULT ADD) ---
app.MapPost("/api/vault/add", async (VaultAsset asset) => {
    var vault = File.Exists(vaultDb) ? JsonSerializer.Deserialize<List<VaultAsset>>(await File.ReadAllTextAsync(vaultDb)) ?? new List<VaultAsset>() : new List<VaultAsset>();
    
    // AES-256 ile mühürle
    asset.Value = SecurityHelper.Encrypt(asset.Value, asset.PassKey); 
    vault.Add(asset);
    
    await File.WriteAllTextAsync(vaultDb, JsonSerializer.Serialize(vault));
    await SendFlowSignal($"ASSET_MINTED: {asset.Title}");
    return Results.Ok();
});

app.Run("http://localhost:6060");

// --- MODELLER ---
public record User(string Username, string Password, string Rank = "Operator");
public record VaultRequest(string Owner, string VaultKey);
public class VaultAsset {
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Title { get; set; } = "";
    public string Value { get; set; } = "";
    public string Owner { get; set; } = "";
    public string PassKey { get; set; } = ""; 
}