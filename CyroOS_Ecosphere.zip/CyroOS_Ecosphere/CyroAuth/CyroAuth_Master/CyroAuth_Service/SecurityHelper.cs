using System.Security.Cryptography;
using System.Text;

namespace CyroAuth_Service;

public static class SecurityHelper
{
    /// <summary>
    /// Veriyi operatörün şifresiyle AES-256 kullanarak mühürler.
    /// </summary>
    public static string Encrypt(string text, string key)
    {
        if (string.IsNullOrEmpty(text)) return string.Empty;

        using Aes aes = Aes.Create();
        // Operatörün şifresini SHA-256 ile 32 byte'lık (256-bit) güvenli anahtara dönüştürür.
        aes.Key = SHA256.HashData(Encoding.UTF8.GetBytes(key));
        // IV (Initialization Vector) sabit 16 byte olarak ayarlanır.
        aes.IV = new byte[16]; 

        using var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
        byte[] buffer = Encoding.UTF8.GetBytes(text);
        byte[] encrypted = encryptor.TransformFinalBlock(buffer, 0, buffer.Length);

        return Convert.ToBase64String(encrypted);
    }

    /// <summary>
    /// Mühürlü veriyi operatörün şifresiyle deşifre eder.
    /// </summary>
    public static string Decrypt(string cipherText, string key)
    {
        if (string.IsNullOrEmpty(cipherText)) return string.Empty;

        try
        {
            using Aes aes = Aes.Create();
            aes.Key = SHA256.HashData(Encoding.UTF8.GetBytes(key));
            aes.IV = new byte[16];

            using var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
            byte[] buffer = Convert.FromBase64String(cipherText);
            byte[] decrypted = decryptor.TransformFinalBlock(buffer, 0, buffer.Length);

            return Encoding.UTF8.GetString(decrypted);
        }
        catch
        {
            // Şifre yanlışsa veya veri mühürü bozulmuşsa erişim engellenir.
            return "!!! ACCESS_DENIED: DECRYPTION_FAILED !!!";
        }
    }
}