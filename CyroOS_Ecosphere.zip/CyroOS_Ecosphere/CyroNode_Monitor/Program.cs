using System.Text.Json; // Hata CS0246 ve CS0103 çözümü için kritik

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options => {
    options.AddDefaultPolicy(policy => policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
});

var app = builder.Build();

app.UseCors();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/node/status", async () => {
    bool isAuth = await Check("http://localhost:6060");
    bool isFlow = await Check("http://localhost:8080");
    
    string rawHistory = "[]";
    if (isFlow) {
        try {
            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(1) };
            var res = await client.GetAsync("http://localhost:8080/api/flow/status");
            if (res.IsSuccessStatusCode) {
                // System.Text.Json kullanarak veriyi güvenli çekiyoruz
                var flowObj = await res.Content.ReadFromJsonAsync<JsonElement>();
                
                // 'history' alanını yakalıyoruz
                if (flowObj.TryGetProperty("history", out JsonElement historyEl)) {
                    rawHistory = historyEl.GetString() ?? "[]";
                }
            }
        } catch { 
            rawHistory = "[]"; 
        }
    }

    return Results.Ok(new {
        Nodes = new[] {
            new { Id = "Auth", Name = "CyroAuth Master", Status = isAuth ? "ONLINE" : "OFFLINE", X = 0, Y = -160 },
            new { Id = "Flow", Name = "CyroFlow Engine", Status = isFlow ? "ACTIVE" : "OFFLINE", X = -220, Y = 100 },
            new { Id = "Vault", Name = "Secure Vault", Status = isAuth ? "ENCRYPTED" : "LOCKED", X = 220, Y = 100 }
        },
        History = rawHistory,
        Sync = isAuth && isFlow ? "99.1%" : "64.2%"
    });
});

async Task<bool> Check(string url) {
    try {
        using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(1) };
        await client.GetAsync(url);
        return true;
    } catch { return false; }
}

app.Run("http://localhost:7070");